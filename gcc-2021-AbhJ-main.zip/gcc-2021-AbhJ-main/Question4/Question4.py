def totalPairs(n, values):
    # Participants code will be here
    return -1

if __name__ == "__main__":
    n = int(input())
    values = list(map(int, input().split()))
    answer = totalPairs(n, values)
    print(answer)