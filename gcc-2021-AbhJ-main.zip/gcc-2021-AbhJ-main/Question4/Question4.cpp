
/**
 * @author      : abhj
 * @created     : Friday Oct 01, 2021 19:33:06 IST
 * @filename    : d.cpp
 */

#include "bits/stdc++.h"
#define int          long long int
#define mp           make_pair
#define pb           emplace_back
#define F            first
#define S            second
using vi       =     std::vector<int>;
using vvi      =     std::vector<vi>;
using pii      =     std::pair<int, int>;
using vpii     =     std::vector<pii>;
using vvpii    =     std::vector<vpii>;
using namespace std;
const int inf  =     1e18 + 10;
const int N    =     2e6 + 10;

int n, a[N], l[N], r[N];
stack<int>s;

void solve() {
	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> a[i];
	fill (l, l + n, - 1);
	fill (r, r + n, - 1);
	for (int i = n - 1; i > -1; i--) {
		while (s.empty() == 0 and a[s.top()] <= a[i])
			s.pop();
		if (s.empty() == 0)
			r[i] = s.top();
		s.push (i);
	}
	s = stack<int>();
	for (int i = 0; i < n; i++) {
		while (s.empty() == 0 and a[s.top()] <= a[i])
			s.pop();
		if (s.empty() == 0)
			l[i] = s.top();
		s.push (i);
	}
	int cnt = 0;
	for (int i = 0; i < n; i++)
		if (~r[i] and ~l[i])
			cnt += !! ((r[i] - i) * (i - l[i]));
	cout << cnt + n - 1;
}

int32_t main() {
	ios_base::sync_with_stdio (false);
	cin.tie (0);
	solve();
	return 0;
}
