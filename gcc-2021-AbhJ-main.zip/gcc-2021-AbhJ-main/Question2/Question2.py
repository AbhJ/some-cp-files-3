

def securitiesBuying(z, security_value):
   no_of_stocks=0
   #participants code here

   return no_of_stocks;


def main():
    z= input().split()
    security_value = []
    security_value = input().split()
    no_of_stocks_purchased=securitiesBuying(z,security_value)
    print(no_of_stocks_purchased)




if __name__ == '__main__':
    main()
