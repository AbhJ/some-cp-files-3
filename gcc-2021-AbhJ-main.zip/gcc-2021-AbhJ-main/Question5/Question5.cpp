
/**
 * @author      : abhj
 * @created     : Friday Oct 01, 2021 22:28:14 IST
 * @filename    : e.cpp
 */

#include "bits/stdc++.h"
#define int          long long int
#define mp           make_pair
#define pb           emplace_back
#define F            first
#define S            second
using vi       =     std::vector<int>;
using vvi      =     std::vector<vi>;
using pii      =     std::pair<int, int>;
using vpii     =     std::vector<pii>;
using vvpii    =     std::vector<vpii>;
using namespace std;
const int inf  =     1e18 + 10;
const int N    =     2e6 + 10;

int n, ans;
vi v;
string s;

void solve() {
	cin >> s;
	n = s.length();
	int cnt = 0;
	for (int i = 0; i < n; i++) {
		if (i != 0 and s[i] != s[i - 1]) {
			if (s[i] == '1')
				v.pb (i - cnt);
			cnt = i;
		}
	}
	if (s[n - 1] == '0')
		v.pb (n - cnt);
	sort (v.begin(), v.end());
	if (v.empty() == 1) {
		cout << "B";
		return;
	}
	if (v.size() == 1) {
		cout << (char) ('A' + (v[0] & 1 ^ 1));
		return;
	}
	int ma = v[v.size() - 1];
	int sm = v[v.size() - 2];
	if (ma & 1 ^ 1) {
		cout << "B";
		return;
	}
	cout << (char) ('A' + ((ma >> 1) + 1 <= sm));
}

int32_t main() {
	ios_base::sync_with_stdio (false);
	cin.tie (0);
	solve();
	return 0;
}
