
def sol(n):	
   #add code

# do not edit below code
def main():
	n=input()
	print(sol(n))

if __name__ == '__main__':
    main()
