using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class GroupFormation {

    static void theHackathon(int n, int m, int a, int b, int f, int s, int t) {
        // Participant code here
    }

    static void Main(string[] args) {
        string[] inputdata = Console.ReadLine().Split(' ');

        int n = Convert.ToInt32(inputdata[0]);

        int m = Convert.ToInt32(inputdata[1]);

        int a = Convert.ToInt32(inputdata[2]);

        int b = Convert.ToInt32(inputdata[3]);

        int f = Convert.ToInt32(inputdata[4]);

        int s = Convert.ToInt32(inputdata[5]);

        int t = Convert.ToInt32(inputdata[6]);

        theHackathon(n, m, a, b, f, s, t);
    }
}
