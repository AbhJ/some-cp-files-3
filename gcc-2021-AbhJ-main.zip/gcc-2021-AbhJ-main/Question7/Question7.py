def countStablePartitions(n, values):

if __name__ == "__main__":
    n = int(input())
    values = list(map(int, input().split()))
    countStablePartitions(n, values)