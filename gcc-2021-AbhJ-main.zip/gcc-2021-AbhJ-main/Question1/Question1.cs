using System;

public class Solution
{
     public static int sol(int n)
    {

    }
	public static void Main()
	{
        int n= Convert.ToInt32(Console.ReadLine());                 
        int answer=sol(n);
        Console.WriteLine(answer);
	}
}
