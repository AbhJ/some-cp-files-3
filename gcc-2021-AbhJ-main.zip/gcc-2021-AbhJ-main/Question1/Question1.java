

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;



class TestClass {

    public static int solution(int n)
    {

    }


    public static void main(String args[] ) throws Exception {
        

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n=Integer.parseInt(br.readLine());
        int answer=solution(n);
        System.out.println(answer);
        
    }
}
